<?php 
include "database/connect.php";

global $connection;
// $query = "insert into users (username,email,address,role_id) values ('alice','alice@gmail.com','yangon',1)";
// $statement = mysqli_query($connection,$query);

// $userQuery = "select * from users";
// $userstatement = mysqli_query($connection,$userQuery);
// $users = mysqli_fetch_array($userstatement);
// var_dump($users);


?>
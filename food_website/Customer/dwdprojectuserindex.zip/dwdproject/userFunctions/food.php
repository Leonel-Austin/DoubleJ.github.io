<?php 


function searchFood($query)
{
    global $connection;
  if($query)
  {
    $searchQuery = "SELECT * FROM `food` WHERE `food_name` LIKE '%".$query."%' ";
    $statement = mysqli_query($connection,$searchQuery);
    $searchedFood = mysqli_fetch_all($statement);
    var_dump($searchedFood);
    return $searchedFood;
  }
}


?>
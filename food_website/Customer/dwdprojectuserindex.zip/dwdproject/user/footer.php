<div style="background-color:whitesmoke;z-index:99;text-align:center" class="container-fluid text-secondary pt-5">
        <div class="row px-xl-5 d-flex justify-content-center align-content-center">
        <div class="col-lg-2 col-md-12 mb-5">
            <img src="../images/logo.jpg" style="width: 100px; height: 100px;object-fit:cover" class="" alt="logo">
        </div>
            <div class="col-lg-4 col-md-12">
                <h5 class="text-secondary text-uppercase mb-4">Our Address</h5>
                
                <p class="mb-2"><i class="fa fa-map-marker-alt text-primary me-2"></i>123 Street, New York, USA</p>
                
            </div>

                    <div class="col-lg-4 col-md-12">
                        <h5 class="text-secondary text-uppercase mb-4"> Contact Us </h5>
                        <div class="d-flex flex-column justify-content-start">
                        <p class="mb-2"><i class="fa fa-envelope text-primary me-2"></i>info@example.com</p>
                        <p class="mb-0"><i class="fa fa-phone-alt text-primary me-2"></i>+012 345 67890</p>
                        </div>
                    </div>
                   
                    <div class="col-lg-2 col-md-12 mb-5">
                      
                        <h6 class="text-secondary text-uppercase mt-4 mb-3">Follow Us on</h6>
                        <div class="d-flex">
                            <a class="btn btn-primary btn-square me-2" href="#"><i class="fab fa-twitter me-1"></i></a>
                            <a class="btn btn-primary btn-square me-2" href="#"><i class="fab fa-facebook-f me-1"></i></a>
                            <a class="btn btn-primary btn-square me-2" href="#"><i class="fab fa-linkedin-in me-1"></i></a>
                            <a class="btn btn-primary btn-square me-2" href="#"><i class="fab fa-instagram me-1"></i></a>
                        </div>
                    </div>
                </div>
                &copy; <a class="text-primary" href="#"></a>2024 . All Rights Reserved
                    By
                    <a class="text-primary" href="https://htmlcodex.com">Double J.com</a>
       
            
        </div>
    </div>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>
</html>
<?php 
include "../database/connect.php";
include "../userFunctions/category.php";
include "../userFunctions/food.php";

global $connection;


$categories = getCategories();


require("./header.php");

if(isset($_GET['search']))
{
  $searchedFood = searchFood($_GET['query']);
}
?>


<!-- products start -->
<div class="" >
<div class="sidebar pb-3">
            <nav class="navbar bg-transparent ">
                <a href="index.html" class="d-flex justify-content-between align-items-center navbar-brand mx-4 mb-3 gap-3">
                <img src="../images/logo.jpg" style="width: 40px; height: 40px;object-fit:cover" class="" alt="logo">
                    <h3>Double J</h3>
                </a>
                
                <div class="navbar-nav w-100">

                    <div class="nav-item  active">
                        <a href="#" class="nav-link" style="color: black;" data-bs-toggle="dropdown"><i class="fa fa-laptop me-2" style="color: white;"></i>Categories</a>
                        <div class="bg-transparent border-0">
                            <?php for($i=0;$i<sizeof($categories);$i++): ?>
                               
                            <a href="button.html" style="color: black;"  class="dropdown-item"><?php echo $categories[$i][1]; ?></a>
                            <?php endfor; ?>
                        </div>
                    </div>
                   
                </div>
            </nav>
        </div>
    <div class="row content">
       

        <div class=" col-lg-12 d-flex justify-content-start ">
            <div class="row my-4">
                <div class="col-md-3 col-sm-4">
                <div style="background-color: white-smoke" class="product-item mb-4">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="https://onecms-res.cloudinary.com/image/upload/s--sEfcyVTf--/c_crop%2Ch_717%2Cw_957%2Cx_153%2Cy_771/c_fill%2Cg_auto%2Ch_622%2Cw_830/f_auto%2Cq_auto/v1/mediacorp/cna/image/2022/04/01/final-2.jpeg?itok=urO6AS9r" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href="user/cart.php"><i class="fa fa-shopping-cart"></i></a>
                                   
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-search"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-2">
                                <a class="h6 text-decoration-none text-dark" href="">Cheesy Pizza</a>
                                <div class="d-flex align-items-center justify-content-center mt-2 text-dark">
                                    <h5 class="text-dark">20000 kyats</h5>
                                </div>
                                <div class="d-flex align-items-center justify-content-center mb-1">
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-4">
                <div style="background-color: white-smoke" class="product-item  mb-4">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="https://onecms-res.cloudinary.com/image/upload/s--sEfcyVTf--/c_crop%2Ch_717%2Cw_957%2Cx_153%2Cy_771/c_fill%2Cg_auto%2Ch_622%2Cw_830/f_auto%2Cq_auto/v1/mediacorp/cna/image/2022/04/01/final-2.jpeg?itok=urO6AS9r" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-shopping-cart"></i></a>
                                   
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-search"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-2">
                                <a class="h6 text-decoration-none text-dark" href="">Cheesy Pizza</a>
                                <div class="d-flex align-items-center justify-content-center mt-2 text-dark">
                                    <h5 class="text-dark">20000 kyats</h5>
                                </div>
                                <div class="d-flex align-items-center justify-content-center mb-1">
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-4">
                <div style="background-color: white-smoke" class="product-item mb-4">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="https://onecms-res.cloudinary.com/image/upload/s--sEfcyVTf--/c_crop%2Ch_717%2Cw_957%2Cx_153%2Cy_771/c_fill%2Cg_auto%2Ch_622%2Cw_830/f_auto%2Cq_auto/v1/mediacorp/cna/image/2022/04/01/final-2.jpeg?itok=urO6AS9r" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-shopping-cart"></i></a>
                                   
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-search"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-2">
                                <a class="h6 text-decoration-none text-dark" href="">Cheesy Pizza</a>
                                <div class="d-flex align-items-center justify-content-center mt-2 text-dark">
                                    <h5 class="text-dark">20000 kyats</h5>
                                </div>
                                <div class="d-flex align-items-center justify-content-center mb-1">
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-4">
                <div style="background-color: white-smoke" class="product-item mb-4">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="https://onecms-res.cloudinary.com/image/upload/s--sEfcyVTf--/c_crop%2Ch_717%2Cw_957%2Cx_153%2Cy_771/c_fill%2Cg_auto%2Ch_622%2Cw_830/f_auto%2Cq_auto/v1/mediacorp/cna/image/2022/04/01/final-2.jpeg?itok=urO6AS9r" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-shopping-cart"></i></a>
                                   
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-search"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-2">
                                <a class="h6 text-decoration-none text-dark" href="">Cheesy Pizza</a>
                                <div class="d-flex align-items-center justify-content-center mt-2 text-dark">
                                    <h5 class="text-dark">20000 kyats</h5>
                                </div>
                                <div class="d-flex align-items-center justify-content-center mb-1">
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-4">
                <div style="background-color: white-smoke" class="product-item mb-4">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="https://onecms-res.cloudinary.com/image/upload/s--sEfcyVTf--/c_crop%2Ch_717%2Cw_957%2Cx_153%2Cy_771/c_fill%2Cg_auto%2Ch_622%2Cw_830/f_auto%2Cq_auto/v1/mediacorp/cna/image/2022/04/01/final-2.jpeg?itok=urO6AS9r" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-shopping-cart"></i></a>
                                   
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-search"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-2">
                                <a class="h6 text-decoration-none text-dark" href="">Cheesy Pizza</a>
                                <div class="d-flex align-items-center justify-content-center mt-2 text-dark">
                                    <h5 class="text-dark">20000 kyats</h5>
                                </div>
                                <div class="d-flex align-items-center justify-content-center mb-1">
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-4">
                <div style="background-color: white-smoke" class="product-item mb-4">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="https://onecms-res.cloudinary.com/image/upload/s--sEfcyVTf--/c_crop%2Ch_717%2Cw_957%2Cx_153%2Cy_771/c_fill%2Cg_auto%2Ch_622%2Cw_830/f_auto%2Cq_auto/v1/mediacorp/cna/image/2022/04/01/final-2.jpeg?itok=urO6AS9r" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-shopping-cart"></i></a>
                                   
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-search"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-2">
                                <a class="h6 text-decoration-none text-dark" href="">Cheesy Pizza</a>
                                <div class="d-flex align-items-center justify-content-center mt-2 text-dark">
                                    <h5 class="text-dark">20000 kyats</h5>
                                </div>
                                <div class="d-flex align-items-center justify-content-center mb-1">
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="col-md-3 col-sm-4">
                <div style="background-color: white-smoke" class="product-item mb-4">
                            <div class="product-img position-relative overflow-hidden">
                                <img class="img-fluid w-100" src="https://onecms-res.cloudinary.com/image/upload/s--sEfcyVTf--/c_crop%2Ch_717%2Cw_957%2Cx_153%2Cy_771/c_fill%2Cg_auto%2Ch_622%2Cw_830/f_auto%2Cq_auto/v1/mediacorp/cna/image/2022/04/01/final-2.jpeg?itok=urO6AS9r" alt="">
                                <div class="product-action">
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-shopping-cart"></i></a>
                                   
                                    <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-search"></i></a>
                                </div>
                            </div>
                            <div class="text-center py-2">
                                <a class="h6 text-decoration-none text-dark" href="">Cheesy Pizza</a>
                                <div class="d-flex align-items-center justify-content-center mt-2 text-dark">
                                    <h5 class="text-dark">20000 kyats</h5>
                                </div>
                                <div class="d-flex align-items-center justify-content-center mb-1">
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                    <small class="fa fa-star text-primary mr-1"></small>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>
</div>
<!-- products end -->
</div>
        <!-- Content End -->


        <!-- Back to Top -->
       
</div>


<?php 

require("./footer.php");

?>